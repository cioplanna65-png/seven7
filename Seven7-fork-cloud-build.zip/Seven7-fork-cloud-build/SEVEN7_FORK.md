# Seven 7 — fork fechado do 3105

Este fork parte do commit upstream `4a15d823b711bc0639de1f3fd2c764b5982d9245` do repositório oficial [YangJiiii/3105](https://github.com/YangJiiii/3105).

## Alterações

- Tela de login obrigatória com a key local temporária `seven7`.
- Botão azul **ENTRAR** e identidade visual preta/roxa Seven 7.
- Ícone novo com o símbolo 7.
- Navegação limitada às abas **Patchs** e **Cleaner**.
- Cleaner preservado usando o serviço original de limpeza limitada.
- Criação, edição, exclusão, importação e exportação de patches removidas da interface.
- Patches prontos devem ser adicionados em `ThreeOneOSFive/Patches/` antes do build. O app instala cada `.3105` empacotado na biblioteca local na primeira abertura.
- **Restore Originals** escreve todos os arquivos originais imediatamente. Se o app-alvo continuar aberto, o processo pode manter o patch em memória; ao fechar e abrir o app-alvo novamente, ele carrega os arquivos originais restaurados.

## Adicionar patches prontos

Copie arquivos `.3105` para `ThreeOneOSFive/Patches/` e abra o projeto no Xcode. A pasta é um recurso do target e será copiada para o bundle. Não é necessário criar patches dentro do Seven 7.

## Build

O projeto deve ser aberto no Xcode em macOS/iOS SDK. Este ambiente Linux não possui Xcode, SDK iOS nem certificados de assinatura, portanto o artefato entregue é o código-fonte forkado e não um IPA assinado.

A chave `seven7` está embutida apenas como gate temporário, conforme solicitado. Ela não deve ser considerada uma autenticação segura; para produção, substitua `Seven7Access.exampleKey` por uma validação no servidor e um fluxo de expiração/revogação.
