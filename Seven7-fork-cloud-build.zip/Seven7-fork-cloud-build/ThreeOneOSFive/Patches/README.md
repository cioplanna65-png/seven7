# Seven 7 bundled patches

Coloque aqui os arquivos `.3105` prontos que devem aparecer na aba **Patchs** do Seven 7.

Na inicialização, o app copia cada pacote para a biblioteca local uma única vez por `packageID`. Esta pasta não oferece criação ou edição de novos patches dentro do app.
