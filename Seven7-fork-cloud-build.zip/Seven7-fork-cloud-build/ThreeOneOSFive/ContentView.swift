import SwiftUI

struct ContentView: View {
    @Environment(\.horizontalSizeClass) private var horizontalSizeClass
    @EnvironmentObject private var patchStore: PatchProjectStore
    @State private var selectedTab = AppSection.patches.rawValue

    var body: some View {
        Group {
            if horizontalSizeClass == .regular {
                regularLayout
            } else {
                compactLayout
            }
        }
        .background(AppTheme.pageBackground.ignoresSafeArea())
        .tint(AppTheme.accent)
        .preferredColorScheme(.dark)
        .patchStorePresentation(patchStore)
    }

    private var compactLayout: some View {
        TabView(selection: $selectedTab) {
            PatchProjectsView()
                .tabItem {
                    Label("Patchs", systemImage: "shippingbox.fill")
                }
                .tag(AppSection.patches.rawValue)

            CleanerView()
                .tabItem {
                    Label("Cleaner", systemImage: "sparkles")
                }
                .tag(AppSection.cleaner.rawValue)
        }
    }

    private var regularLayout: some View {
        NavigationSplitView {
            List(selection: $selectedTab) {
                Label("Patchs", systemImage: "shippingbox.fill")
                    .tag(AppSection.patches.rawValue)
                Label("Cleaner", systemImage: "sparkles")
                    .tag(AppSection.cleaner.rawValue)
            }
            .navigationTitle("SEVEN 7")
            .navigationSplitViewColumnWidth(min: 190, ideal: 220, max: 280)
        } detail: {
            if selectedTab == AppSection.cleaner.rawValue {
                CleanerView()
            } else {
                PatchProjectsView()
            }
        }
        .navigationSplitViewStyle(.balanced)
    }
}
