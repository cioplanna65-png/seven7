import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var patchStore: PatchProjectStore
    @State private var selectedTab = AppSection.patches.rawValue

    var body: some View {
        TabView(selection: $selectedTab) {
            PatchProjectsView()
                .tabItem {
                    Label("Patchs", systemImage: "shippingbox.fill")
                }
                .tag(AppSection.patches.rawValue)

            CleanerView()
                .tabItem {
                    Label("Cleaner", systemImage: "sparkles")
                }
                .tag(AppSection.cleaner.rawValue)
        }
        .background(AppTheme.pageBackground.ignoresSafeArea())
        .tint(AppTheme.accent)
        .preferredColorScheme(.dark)
        .patchStorePresentation(patchStore)
    }
}
