import SwiftUI

struct ContentView: View {
    @EnvironmentObject private var patchStore: PatchProjectStore

    var body: some View {
        PatchProjectsView()
        .background(AppTheme.pageBackground.ignoresSafeArea())
        .tint(AppTheme.accent)
        .preferredColorScheme(.dark)
        .patchStorePresentation(patchStore)
    }
}
