import SwiftUI

struct PatchProjectsView: View {
    @EnvironmentObject private var store: PatchProjectStore
    @EnvironmentObject private var licenseManager: LicenseManager
    @Environment(\.openURL) private var openURL
    @State private var message: String?

    var body: some View {
        NavigationStack {
            List {
                Section {
                    freeFireCard
                }

                if licenseManager.isBusy && licenseManager.files.isEmpty {
                    ProgressView("Validando licença…")
                        .frame(maxWidth: .infinity)
                        .listRowSeparator(.hidden)
                } else if licenseManager.files.isEmpty {
                    VStack(spacing: 10) {
                        Seven7Mark(size: 52)
                        Text("Nenhuma função autorizada")
                            .font(.headline)
                        Text("As funções disponíveis para sua key aparecerão aqui.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                            .multilineTextAlignment(.center)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 64)
                    .listRowSeparator(.hidden)
                } else {
                    Section {
                        ForEach(licenseManager.files) { file in
                            remoteRow(file)
                        }
                    } header: {
                        HStack {
                            Text("Funções disponíveis")
                            Spacer()
                            Button("Baixar todos") { downloadAll() }
                                .font(.caption.weight(.semibold))
                                .disabled(licenseManager.files.allSatisfy { isInstalled($0) } || !licenseManager.downloading.isEmpty || store.isBusy)
                        }
                    } footer: {
                        Button {
                            openFreeFire()
                        } label: {
                            Text("Abrir Free Fire")
                                .font(.headline.weight(.bold))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(AppTheme.accent)
                        .listRowInsets(EdgeInsets(top: 14, leading: 16, bottom: 14, trailing: 16))
                    }
                }
            }
            .listStyle(.insetGrouped)
            .navigationTitle("Funções")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .principal) {
                    HStack(spacing: 8) {
                        Seven7Mark(size: 24)
                        Text("SEVEN 7")
                            .font(.headline.weight(.black))
                            .tracking(1.1)
                    }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        if let url = URL(string: "https://discord.gg/eBk8HAXGGJ") {
                            openURL(url)
                        }
                    } label: {
                        Image(systemName: "bubble.left.and.bubble.right.fill")
                            .font(.caption.weight(.bold))
                            .frame(width: 28, height: 28)
                    }
                    .accessibilityLabel("Abrir Discord")
                }
            }
            .alert("Funções", isPresented: Binding(
                get: { message != nil },
                set: { if !$0 { message = nil } }
            )) {
                Button("OK", role: .cancel) { message = nil }
            } message: {
                Text(message ?? "")
            }
        }
    }

    private var freeFireCard: some View {
        HStack(spacing: 14) {
            ZStack {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .fill(LinearGradient(colors: [AppTheme.accent, Color.black], startPoint: .topLeading, endPoint: .bottomTrailing))
                Image(systemName: "flame.fill")
                    .font(.system(size: 30, weight: .bold))
                    .foregroundStyle(.white)
            }
            .frame(width: 68, height: 68)
            VStack(alignment: .leading, spacing: 8) {
                Text("Free Fire")
                    .font(.title3.weight(.bold))
                HStack(spacing: 6) {
                    Circle().fill(Color.green).frame(width: 9, height: 9)
                    Text("Ativo")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.green)
                }
            }
            Spacer()
        }
        .padding(.vertical, 8)
        .listRowSeparator(.hidden)
    }

    @ViewBuilder
    private func remoteRow(_ file: LicenseFile) -> some View {
        let installed = store.items.first {
            $0.origin?.repositoryURL == LicenseManager.baseURL &&
            $0.origin?.packageIdentifier == String(file.id)
        }
        HStack(spacing: 12) {
            Text("💀")
                .font(.system(size: 25))
                .frame(width: 34, height: 34)
            VStack(alignment: .leading, spacing: 4) {
                Text(file.displayName)
                    .font(.body.weight(.semibold))
                if !file.version.isEmpty {
                    Text("v\(file.version)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            Spacer()
            if let installed {
                NavigationLink {
                    PatchProjectDetailView(store: store, projectID: installed.id)
                } label: {
                    Text("Abrir")
                }
                .buttonStyle(.borderedProminent)
            } else {
                Button {
                    download(file)
                } label: {
                    if licenseManager.downloading.contains(file.id) {
                        ProgressView()
                    } else {
                        Text("Baixar")
                    }
                }
                .buttonStyle(.borderedProminent)
                .disabled(licenseManager.downloading.contains(file.id) || store.isBusy)
            }
        }
        .padding(.vertical, 4)
    }

    private func download(_ file: LicenseFile) {
        Task {
            do {
                let data = try await licenseManager.download(file)
                _ = await store.installLicensePackage(data: data, file: file)
            } catch {
                let detail = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
                message = "\(file.displayName): \(detail)"
            }
        }
    }

    private func openFreeFire() {
        message = "Abrindo Free Fire…"
        if let url = URL(string: "freefireth://") {
            openURL(url)
        }
    }

    private func isInstalled(_ file: LicenseFile) -> Bool {
        store.items.contains {
            $0.origin?.repositoryURL == LicenseManager.baseURL &&
            $0.origin?.packageIdentifier == String(file.id)
        }
    }

    private func downloadAll() {
        let pending = licenseManager.files.filter { !isInstalled($0) }
        guard !pending.isEmpty, licenseManager.downloading.isEmpty else { return }
        Task {
            var failures: [String] = []
            for file in pending {
                do {
                    let data = try await licenseManager.download(file)
                    _ = await store.installLicensePackage(data: data, file: file)
                } catch {
                    let detail = (error as? LocalizedError)?.errorDescription ?? error.localizedDescription
                    failures.append("\(file.displayName): \(detail)")
                }
            }
            if !failures.isEmpty {
                message = "Não foi possível baixar: \(failures.joined(separator: ", "))."
            }
        }
    }
}

private struct PatchProjectRow: View {
    let item: PatchLibraryItem
    let language: AppLanguage

    var body: some View {
        HStack(spacing: 12) {
            AppRowIcon(systemName: item.isLocked ? "lock.doc.fill" : "shippingbox.fill")
            VStack(alignment: .leading, spacing: 3) {
                Text(item.project?.name ?? "Patch protegido")
                    .font(.body.weight(.semibold))
                    .foregroundStyle(.primary)
                    .lineLimit(1)
                InstalledContentKindBadge(kind: .patch, language: language)
                if let author = item.project?.author, !author.isEmpty {
                    Text("Por \(author)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                Text(rowDetail)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            if item.summary.isPasswordProtected {
                Image(systemName: "key.fill")
                    .font(.caption)
                    .foregroundStyle(AppTheme.accent)
            }
        }
        .padding(.vertical, 4)
    }

    private var rowDetail: String {
        if item.isLocked { return "Toque para desbloquear" }
        return "\((item.project?.rules.count ?? 0) + (item.project?.directories.count ?? 0)) itens prontos"
    }
}

private enum InstalledContentKind {
    case patch

    var localizationKey: String { "installed.kind.patch" }
    var systemImage: String { "shippingbox.fill" }
}

private struct InstalledContentKindBadge: View {
    let kind: InstalledContentKind
    let language: AppLanguage

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: kind.systemImage)
            Text(language.text(kind.localizationKey))
        }
        .font(.caption2.weight(.semibold))
        .foregroundStyle(AppTheme.accent)
        .padding(.horizontal, 8)
        .frame(height: 24)
        .background(AppTheme.accent.opacity(0.12), in: Capsule())
        .fixedSize()
    }
}

struct PatchUnlockView: View {
    @Environment(\.appLanguage) private var language
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var store: PatchProjectStore
    let request: PatchPasswordRequest
    @State private var password = ""

    var body: some View {
        NavigationStack {
            Form {
                Section {
                    SecureField(language.text("patch.password"), text: $password)
                        .textContentType(.password)
                        .submitLabel(.done)
                        .onSubmit(unlock)
                        .onChange(of: password) { _ in store.clearUnlockError() }
                    if let errorKey = store.unlockErrorKey {
                        Text(language.text(errorKey))
                            .font(.footnote)
                            .foregroundStyle(.red)
                    }
                }
            }
            .navigationTitle(language.text("patch.unlock"))
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(language.text("common.cancel")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(language.text("patch.unlock"), action: unlock)
                        .disabled(password.isEmpty || store.isBusy)
                }
            }
        }
    }

    private func unlock() {
        guard !password.isEmpty else { return }
        store.unlock(password: password)
    }
}

private struct PatchStorePresentationModifier: ViewModifier {
    @ObservedObject var store: PatchProjectStore

    func body(content: Content) -> some View {
        content
            .sheet(item: $store.passwordRequest, onDismiss: store.cancelUnlock) { request in
                PatchUnlockView(store: store, request: request)
            }
    }
}

extension View {
    func patchStorePresentation(_ store: PatchProjectStore) -> some View {
        modifier(PatchStorePresentationModifier(store: store))
    }
}
private struct PatchProjectDetailView: View {
    @Environment(\.appLanguage) private var language
    @ObservedObject var store: PatchProjectStore
    let projectID: UUID
    @State private var isWorking = false
    @State private var actionAlert: PatchStoreAlert?

    private var item: PatchLibraryItem? {
        store.items.first(where: { $0.id == projectID })
    }

    private var receipt: PatchTransactionReceipt? {
        DevicePatchService.latestReceipt(projectID: projectID)
    }

    private var isWorkspaceProject: Bool {
        (item?.summary.schemaVersion ?? 1) >= 2
    }

    var body: some View {
        VStack(spacing: 18) {
            Spacer()
            Button { apply() } label: {
                Label("Apply Funções", systemImage: "checkmark.shield.fill")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
            .tint(AppTheme.accent)
            .frame(maxWidth: 320)
            .disabled(isWorking || receipt != nil)

            if receipt != nil {
                Button(role: .destructive) { prepareRestore() } label: {
                    Label(language.text("patch.restore"), systemImage: "arrow.uturn.backward.circle")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)
                .controlSize(.large)
                .frame(maxWidth: 320)
                .disabled(isWorking)
            }
            Spacer()
        }
        .padding(24)
        .toolbar {
            ToolbarItem(placement: .navigationBarTrailing) {
                if isWorking {
                    ProgressView()
                }
            }
        }
        .alert(item: $actionAlert) { alert in
            Alert(
                title: Text(language.text(alert.titleKey)),
                message: Text(alert.message(language: language)),
                dismissButton: .default(Text(language.text("common.ok")))
            )
        }
    }

    private func actionLabel(_ key: String, systemImage: String) -> some View {
        Label(language.text(key), systemImage: systemImage)
            .frame(maxWidth: .infinity, alignment: .leading)
    }

    private func patchInfoRow(
        label: String,
        value: String
    ) -> some View {
        patchInfoRow(label: label) {
            Text(value)
                .foregroundStyle(.primary)
        }
    }

    private func patchInfoRow<Content: View>(
        label: String,
        @ViewBuilder value: () -> Content
    ) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 12) {
            Text(label)
                .foregroundStyle(.secondary)
            Spacer(minLength: 16)
            value()
                .multilineTextAlignment(.trailing)
                .fixedSize(horizontal: false, vertical: true)
        }
        .font(.subheadline)
        .padding(.vertical, 5)
    }

    private func ruleSummary(_ rule: PatchRule) -> some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(rule.bundleID)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.primary)
            Text(rule.relativePath)
                .font(.caption.monospaced())
                .foregroundStyle(.secondary)
                .lineLimit(2)
            Label(rule.replacementFilename, systemImage: "arrow.triangle.2.circlepath")
                .font(.caption)
                .foregroundStyle(AppTheme.accent)
        }
        .padding(.vertical, 3)
    }

    private func apply() {
        guard let item, let baseProject = item.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                let project = item.summary.schemaVersion >= 2 && item.canInspectContents
                    ? try PatchProjectLibrary.synchronizeWorkspace(item: item)
                    : baseProject
                _ = try DevicePatchService.apply(project: project)
                await MainActor.run {
                    store.reload()
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.applied_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: privateErrorKey(for: error),
                        messageArgument: privateErrorArgument(for: error)
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.apply")
                }
            }
        }
    }

    private func prepareRestore() {
        guard let receipt else { return }
        // Restore the on-disk originals now. If the target app is still open,
        // its in-memory process can keep showing the patch until it exits.
        restore(receipt: receipt, allowChangedTargets: true)
    }

    private func restore(receipt: PatchTransactionReceipt, allowChangedTargets: Bool) {
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.restore(
                    receipt: receipt,
                    allowChangedTargets: allowChangedTargets
                )
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.done", messageKey: "patch.restored_message")
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: privateErrorKey(for: error),
                        messageArgument: privateErrorArgument(for: error)
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(titleKey: "common.failed", messageKey: "patch.error.restore")
                }
            }
        }
    }

    private func resetToAppliedState() {
        guard let receipt, let project = item?.project else { return }
        isWorking = true
        Task.detached(priority: .userInitiated) {
            do {
                try DevicePatchService.resetToAppliedState(
                    receipt: receipt,
                    project: project
                )
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.done",
                        messageKey: "patch.reset_message"
                    )
                }
            } catch let error as PatchPackageError {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: privateErrorKey(for: error),
                        messageArgument: privateErrorArgument(for: error)
                    )
                }
            } catch {
                await MainActor.run {
                    isWorking = false
                    actionAlert = PatchStoreAlert(
                        titleKey: "common.failed",
                        messageKey: "patch.error.reset"
                    )
                }
            }
        }
    }

    private func privateErrorKey(for error: PatchPackageError) -> String {
        guard item?.project?.isPrivate == true,
              item?.isAuthorCopy == false else {
            return error.localizationKey
        }
        return "patch.error.private_operation"
    }

    private func privateErrorArgument(for error: PatchPackageError) -> String? {
        guard item?.project?.isPrivate == true,
              item?.isAuthorCopy == false else {
            return error.localizationArgument
        }
        return nil
    }
}
