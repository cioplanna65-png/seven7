import SwiftUI
import UIKit

@main
struct ThreeOneOSFiveApp: App {
    @StateObject private var appState = AppState()
    @StateObject private var patchDraftCoordinator = PatchDraftCoordinator()
    @StateObject private var fileOperationCoordinator = FileOperationCoordinator()
    @StateObject private var patchStore = PatchProjectStore()
    @StateObject private var licenseManager = LicenseManager()
    @Environment(\.scenePhase) private var scenePhase

    init() {
        setupLogCapture()
        log("app: Seven 7 launching — iOS \(AppInfo.osVersion) (\(AppInfo.osBuild)) \(AppInfo.machineName)")
    }

    var body: some Scene {
        WindowGroup {
            Group {
                if licenseManager.isAuthenticated {
                    ContentView()
                        .environmentObject(appState)
                        .environmentObject(patchDraftCoordinator)
                        .environmentObject(fileOperationCoordinator)
                        .environmentObject(patchStore)
                        .environmentObject(licenseManager)
                        .onAppear {
                            appState.detectSupport()
                            licenseManager.startMonitoring {
                                patchStore.removeLicensePackages()
                            }
                        }
                        .onDisappear { licenseManager.stopMonitoring() }
                        .onChange(of: scenePhase) { phase in
                            guard phase == .active else { return }
                            appState.detectSupport()
                            Task {
                                if !(await licenseManager.revalidate()) {
                                    patchStore.removeLicensePackages()
                                }
                            }
                        }
                } else {
                    SevenLoginView(licenseManager: licenseManager)
                }
            }
            .preferredColorScheme(.dark)
        }
    }
}

class AppState: ObservableObject {
    @Published var exploitStatus: ExploitStatus = .notStarted
    @Published var unsupportedMessage: String?
    @Published var kernelExploitRunning = false

    private var autoRunAttempted = false

    var kernelExploitApplicable: Bool {
        KernelExploit.isApplicable(
            major: AppInfo.versionTuple.major,
            minor: AppInfo.versionTuple.minor,
            patch: AppInfo.versionTuple.patch,
            build: AppInfo.osBuild
        )
    }

    var isSupported: Bool { unsupportedMessage == nil }

    func detectSupport() {
        let v = AppInfo.versionTuple
        let supported = ExploitSupportPolicy.isSupported(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
#if targetEnvironment(simulator)
        if ProcessInfo.processInfo.arguments.contains("--simulate-access") {
            exploitStatus = .success(method: "Simulator preview")
        }
#endif

        unsupportedMessage = supported ? nil : "iOS \(AppInfo.osVersion) (\(AppInfo.osBuild))"
        if let unsupportedMessage {
            exploitStatus = .unsupported(unsupportedMessage)
            return
        }

        let applicable = KernelExploit.isApplicable(
            major: v.major,
            minor: v.minor,
            patch: v.patch,
            build: AppInfo.osBuild
        )
        guard applicable else { return }

        refreshKernelExploitStatus()
        maybeAutoRunKernelExploit()
    }

    private func maybeAutoRunKernelExploit() {
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed,
              !autoRunAttempted else { return }
        autoRunAttempted = true
        log("app: starting kernel exploit automatically")
        runKernelExploitIfNeeded()
    }

    private func refreshKernelExploitStatus() {
        guard !kernelExploitRunning else { return }

        // iOS < 26: kernel R/W success persists (no sandbox probe)
        // iOS >= 26: verify full sandbox escape is still active
        if KernelExploit.requiresSandboxEscape {
            if KernelExploit.hasSandboxAccess() {
                if !exploitStatus.isSuccess {
                    exploitStatus = .success(method: "kexploit")
                    log("app: existing sandbox access is still active; skipping kernel exploit")
                }
            } else if exploitStatus.isSuccess {
                exploitStatus = .notStarted
                log("app: sandbox access is no longer active")
            }
        }
    }

    func runKernelExploitIfNeeded() {
        refreshKernelExploitStatus()
        guard !kernelExploitRunning,
              !exploitStatus.isSuccess,
              !exploitStatus.isFailed else { return }
        kernelExploitRunning = true
        exploitStatus = .notStarted
        log("app: running kernel exploit on background...")
        DispatchQueue.global(qos: .userInitiated).async {
            let ok = KernelExploit.run()
            DispatchQueue.main.async {
                self.kernelExploitRunning = false
                if ok {
                    self.exploitStatus = .success(method: "kexploit")
                    if KernelExploit.requiresSandboxEscape {
                        log("app: kernel exploit success — sandbox access verified")
                    } else {
                        log("app: kernel exploit success — kernel access active")
                    }
                } else {
                    self.exploitStatus = .failed(method: "kexploit", code: -1)
                    log("app: kernel exploit failed — relaunch the app before retrying")
                }
            }
        }
    }
}

struct SevenLoginView: View {
    @ObservedObject var licenseManager: LicenseManager

    @State private var key = ""
    @FocusState private var keyFieldFocused: Bool

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color.black, Color(red: 0.08, green: 0.02, blue: 0.14)],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()

            Circle()
                .fill(Color.purple.opacity(0.18))
                .frame(width: 280, height: 280)
                .blur(radius: 55)
                .offset(x: 120, y: -280)

            VStack(spacing: 0) {
                Seven7Mark(size: 88)
                    .padding(.bottom, 22)

                Text("SEVEN 7")
                    .font(.system(size: 28, weight: .black, design: .rounded))
                    .tracking(3)
                    .foregroundStyle(.white)

                Text("Acesso ao app")
                    .font(.subheadline.weight(.medium))
                    .foregroundStyle(.white.opacity(0.58))
                    .padding(.top, 6)
                    .padding(.bottom, 36)

                VStack(alignment: .leading, spacing: 10) {
                    Text("KEY DE ACESSO")
                        .font(.caption.weight(.bold))
                        .tracking(1.4)
                        .foregroundStyle(.white.opacity(0.58))

                    SecureField("Digite sua key", text: $key)
                        .textContentType(.password)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .submitLabel(.go)
                        .focused($keyFieldFocused)
                        .onSubmit(login)
                        .padding(.horizontal, 16)
                        .frame(height: 52)
                        .foregroundStyle(.white)
                        .tint(.purple)
                        .background(
                            RoundedRectangle(cornerRadius: 15, style: .continuous)
                                .fill(Color.white.opacity(0.08))
                        )
                        .overlay {
                            RoundedRectangle(cornerRadius: 15, style: .continuous)
                                .stroke(Color.purple.opacity(0.52), lineWidth: 1)
                        }
                }
                .frame(maxWidth: 390)

                if let errorMessage = licenseManager.errorMessage {
                    Text(errorMessage)
                        .font(.footnote.weight(.medium))
                        .foregroundStyle(.red.opacity(0.92))
                        .padding(.top, 12)
                }

                Button {
                    login()
                } label: {
                    HStack(spacing: 9) {
                        Text("ENTRAR")
                            .font(.headline.weight(.bold))
                        Image(systemName: "arrow.right")
                            .font(.headline.weight(.bold))
                    }
                    .frame(maxWidth: 390, minHeight: 52)
                }
                .buttonStyle(.plain)
                .foregroundStyle(.white)
                .background(
                    RoundedRectangle(cornerRadius: 15, style: .continuous)
                        .fill(Color.blue)
                )
                .shadow(color: Color.blue.opacity(0.34), radius: 14, y: 7)
                .padding(.top, 22)
            }
            .padding(.horizontal, 28)
        }
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.25) {
                keyFieldFocused = true
            }
        }
    }

    private func login() {
        keyFieldFocused = false
        Task {
            let valid = await licenseManager.validate(key: key)
            if !valid {
                await MainActor.run {
                    key = ""
                    keyFieldFocused = true
                }
            }
        }
    }
}

struct Seven7Mark: View {
    let size: CGFloat

    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: size * 0.25, style: .continuous)
                .fill(Color.black)
                .overlay {
                    RoundedRectangle(cornerRadius: size * 0.25, style: .continuous)
                        .stroke(
                            LinearGradient(
                                colors: [Color.purple, Color.purple.opacity(0.24)],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            ),
                            lineWidth: 2
                        )
                }
            Text("7")
                .font(.system(size: size * 0.68, weight: .black, design: .rounded))
                .foregroundStyle(
                    LinearGradient(
                        colors: [Color.purple.opacity(0.95), Color(red: 0.46, green: 0.18, blue: 0.82)],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                )
        }
        .frame(width: size, height: size)
        .shadow(color: Color.purple.opacity(0.38), radius: 18)
        .accessibilityHidden(true)
    }
}
