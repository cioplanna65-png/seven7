import Foundation

enum BundledPatchInstaller {
    static func installBundledPatches(
        bundle: Bundle = .main,
        fileManager: FileManager = .default
    ) {
        guard let sourceDirectory = bundle.url(
            forResource: "Patches",
            withExtension: nil,
            subdirectory: nil
        ) else {
            return
        }

        guard let packageRoot = try? PatchProjectLibrary.packageRootURL(fileManager: fileManager),
              let sourceURLs = try? fileManager.contentsOfDirectory(
                at: sourceDirectory,
                includingPropertiesForKeys: [.isRegularFileKey, .isSymbolicLinkKey],
                options: [.skipsHiddenFiles]
              ) else {
            return
        }

        let installedIDs = Set((try? fileManager.contentsOfDirectory(
            at: packageRoot,
            includingPropertiesForKeys: [.isRegularFileKey, .isSymbolicLinkKey],
            options: [.skipsHiddenFiles]
        ) ?? []).compactMap { url -> UUID? in
            guard url.pathExtension.lowercased() == "3105",
                  let data = try? PatchProjectLibrary.readPackage(at: url),
                  let summary = try? PatchPackageCodec.inspect(data) else {
                return nil
            }
            return summary.packageID
        })

        for sourceURL in sourceURLs where sourceURL.pathExtension.lowercased() == "3105" {
            do {
                let data = try PatchProjectLibrary.readPackage(at: sourceURL)
                let summary = try PatchPackageCodec.inspect(data)
                guard !installedIDs.contains(summary.packageID) else { continue }
                _ = try PatchProjectLibrary.save(
                    data: data,
                    projectName: sourceURL.deletingPathExtension().lastPathComponent,
                    fileManager: fileManager
                )
                log("patch: bundled package installed \(sourceURL.lastPathComponent)")
            } catch {
                log("patch: bundled package rejected \(sourceURL.lastPathComponent)")
            }
        }
    }
}
