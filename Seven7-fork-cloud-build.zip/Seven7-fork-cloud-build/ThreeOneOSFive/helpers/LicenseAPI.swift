import Foundation
import CryptoKit
import Security
import UIKit

struct LicenseFile: Codable, Identifiable, Equatable {
    let id: Int
    let displayName: String
    let version: String
    let sha256: String
    let fileSize: Int

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        id = try values.decode(Int.self, forKey: .id)
        displayName = try values.decodeIfPresent(String.self, forKey: .displayName) ?? "Patch"
        version = try values.decodeIfPresent(String.self, forKey: .version) ?? ""
        sha256 = try values.decodeIfPresent(String.self, forKey: .sha256) ?? ""
        fileSize = try values.decodeIfPresent(Int.self, forKey: .fileSize) ?? 0
    }
}

struct LicenseValidationResponse: Codable {
    let ok: Bool
    let licenseId: Int?
    let internalId: String?
    let activatedAt: Date?
    let expiresAt: Date?
    let resetRemaining: Bool?
    let files: [LicenseFile]?
    let code: String?
    let message: String?

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        ok = try values.decodeIfPresent(Bool.self, forKey: .ok) ?? false
        licenseId = try values.decodeIfPresent(Int.self, forKey: .licenseId)
        internalId = try values.decodeIfPresent(String.self, forKey: .internalId)
        activatedAt = try values.decodeIfPresent(Date.self, forKey: .activatedAt)
        expiresAt = try values.decodeIfPresent(Date.self, forKey: .expiresAt)
        resetRemaining = try values.decodeIfPresent(Bool.self, forKey: .resetRemaining)
        files = try values.decodeIfPresent([LicenseFile].self, forKey: .files)
        code = try values.decodeIfPresent(String.self, forKey: .code)
        message = try values.decodeIfPresent(String.self, forKey: .message)
    }
}

private struct DownloadGrantResponse: Codable {
    let ok: Bool
    let fileId: Int?
    let downloadToken: String?
    let expiresAt: Date?
    let code: String?
    let message: String?

    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        ok = try values.decodeIfPresent(Bool.self, forKey: .ok) ?? false
        fileId = try values.decodeIfPresent(Int.self, forKey: .fileId)
        downloadToken = try values.decodeIfPresent(String.self, forKey: .downloadToken)
        expiresAt = try values.decodeIfPresent(Date.self, forKey: .expiresAt)
        code = try values.decodeIfPresent(String.self, forKey: .code)
        message = try values.decodeIfPresent(String.self, forKey: .message)
    }
}

enum LicenseError: LocalizedError {
    case invalidResponse
    case rejected(String, String? = nil)
    case downloadRejected
    case checksumMismatch
    case sizeMismatch
    case invalidConfiguration
    case serverMessage(String)

    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "Resposta inválida do servidor."
        case .rejected(let message, _): return message
        case .downloadRejected: return "O servidor não autorizou o download."
        case .checksumMismatch: return "A verificação de segurança do patch falhou."
        case .sizeMismatch: return "O tamanho do patch não confere."
        case .invalidConfiguration: return "Configuração da API incompleta."
        case .serverMessage(let message): return message
        }
    }
}

@MainActor
final class LicenseManager: ObservableObject {
    static let baseURL = URL(string: "https://licenkeydash-anvun4wk.manus.space/api/v1")!
    private static let clientID = "ios_XIKJIoCehkT1rg"
    private static let clientSecret = "yLwV_UsMuKKFiTqfzFewQMh8ThZoV5AZoOp26me_3us"

    @Published private(set) var key = ""
    @Published private(set) var files: [LicenseFile] = []
    @Published private(set) var expiresAt: Date?
    @Published private(set) var isAuthenticated = false
    @Published private(set) var isBusy = false
    @Published var errorMessage: String?
    private var lastFailureWasTerminal = false

    private var monitorTask: Task<Void, Never>?
    private let fingerprint = DeviceFingerprint.value

    init() {
        if let savedKey = LicenseCredentialStore.read(), !savedKey.isEmpty {
            key = savedKey
            Task { [weak self] in
                guard let self else { return }
                _ = await self.revalidate()
            }
        }
    }

    deinit { monitorTask?.cancel() }

    func validate(key: String) async -> Bool {
        let normalized = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty else {
            errorMessage = "Digite sua key."
            return false
        }
        isBusy = true
        errorMessage = nil
        defer { isBusy = false }
        do {
            let response: LicenseValidationResponse = try await request(
                path: "license/validate",
                method: "POST",
                body: [
                    "key": normalized,
                    "deviceFingerprint": fingerprint,
                    "deviceLabel": UIDevice.current.name,
                    "platform": "ios"
                ]
            )
            guard response.ok else {
                throw LicenseError.rejected(
                    response.message ?? response.code ?? "Key recusada.",
                    response.code
                )
            }
            self.key = normalized
            self.files = response.files ?? []
            self.expiresAt = response.expiresAt
            self.isAuthenticated = true
            LicenseCredentialStore.save(normalized)
            return true
        } catch {
            if case LicenseError.rejected(_, let code) = error {
                lastFailureWasTerminal = [
                    "KEY_EXPIRED", "KEY_INACTIVE", "KEY_NOT_FOUND", "DEVICE_MISMATCH"
                ].contains(code)
            } else {
                lastFailureWasTerminal = false
            }
            if !isAuthenticated || lastFailureWasTerminal {
                isAuthenticated = false
                files = []
                key = ""
                expiresAt = nil
                LicenseCredentialStore.remove()
            }
            errorMessage = (error as? LocalizedError)?.errorDescription
                ?? "Falha na resposta da API: \(error.localizedDescription)"
            return false
        }
    }

    func revalidate() async -> Bool {
        guard !key.isEmpty else { return false }
        let result = await validate(key: key)
        return result || (isAuthenticated && !lastFailureWasTerminal)
    }

    func startMonitoring(onInvalidated: @escaping @MainActor () async -> Void) {
        monitorTask?.cancel()
        monitorTask = Task { [weak self] in
            guard let self else { return }
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 60_000_000_000)
                guard !Task.isCancelled else { return }
                let valid = await self.revalidate()
                if !valid {
                    await onInvalidated()
                    return
                }
            }
        }
    }

    func stopMonitoring() {
        monitorTask?.cancel()
        monitorTask = nil
    }

    func download(_ file: LicenseFile) async throws -> Data {
        guard isAuthenticated, !key.isEmpty else { throw LicenseError.downloadRejected }
        let grant: DownloadGrantResponse = try await request(
            path: "files/\(file.id)/grant",
            method: "POST",
            body: [
                "key": key,
                "deviceFingerprint": fingerprint,
                "deviceLabel": UIDevice.current.name,
                "platform": "ios"
            ]
        )
        guard grant.ok, let token = grant.downloadToken else {
            throw LicenseError.rejected(
                grant.message ?? grant.code ?? "Download não autorizado.",
                grant.code
            )
        }
        var components = URLComponents(
            url: Self.baseURL.appendingPathComponent("download/\(token)"),
            resolvingAgainstBaseURL: false
        )!
        components.queryItems = [URLQueryItem(name: "deviceFingerprint", value: fingerprint)]
        var request = URLRequest(url: components.url!)
        request.timeoutInterval = 120
        addHeaders(to: &request)
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw LicenseError.downloadRejected
        }
        let contentType = http.value(forHTTPHeaderField: "Content-Type") ?? ""
        if contentType.localizedCaseInsensitiveContains("json") || data.first == 123 {
            if let payload = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
               let message = (payload["message"] as? String) ?? (payload["error"] as? String) {
                throw LicenseError.serverMessage(message)
            }
            throw LicenseError.downloadRejected
        }
        if file.fileSize > 0, data.count != file.fileSize {
            throw LicenseError.sizeMismatch
        }
        let expectedHash = file.sha256.trimmingCharacters(in: .whitespacesAndNewlines)
        if expectedHash.count == 64 {
            let digest = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
            guard digest.caseInsensitiveCompare(expectedHash) == .orderedSame else {
                throw LicenseError.checksumMismatch
            }
        }
        return data
    }

    private func request<T: Decodable>(
        path: String,
        method: String,
        body: [String: String]
    ) async throws -> T {
        var request = URLRequest(url: Self.baseURL.appendingPathComponent(path))
        request.httpMethod = method
        request.timeoutInterval = 30
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        addHeaders(to: &request)
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .custom { decoder in
            let value = try decoder.singleValueContainer().decode(String.self)
            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            if let date = formatter.date(from: value) { return date }
            formatter.formatOptions = [.withInternetDateTime]
            if let date = formatter.date(from: value) { return date }
            throw DecodingError.dataCorruptedError(
                in: try decoder.singleValueContainer(),
                debugDescription: "Invalid ISO-8601 date: \(value)"
            )
        }
        let (data, response) = try await URLSession.shared.data(for: request)
        if let http = response as? HTTPURLResponse, !(200..<300).contains(http.statusCode) {
            if let decoded = try? decoder.decode(T.self, from: data) { return decoded }
            throw LicenseError.invalidResponse
        }
        return try decoder.decode(T.self, from: data)
    }

    private func addHeaders(to request: inout URLRequest) {
        request.setValue(Self.clientID, forHTTPHeaderField: "X-Client-Id")
        request.setValue(Self.clientSecret, forHTTPHeaderField: "X-Client-Secret")
    }
}

private enum LicenseCredentialStore {
    private static let service = "seven7.license"
    private static let account = "active-license-key"

    static func save(_ key: String) {
        let base: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(base as CFDictionary)
        var query = base
        query[kSecValueData as String] = Data(key.utf8)
        query[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        SecItemAdd(query as CFDictionary, nil)
    }

    static func read() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }

    static func remove() {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account
        ]
        SecItemDelete(query as CFDictionary)
    }
}

enum DeviceFingerprint {
    private static let service = "seven7.license"
    private static let account = "device-fingerprint"

    static var value: String {
        if let existing = read(), !existing.isEmpty { return existing }
        let created = UUID().uuidString
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: Data(created.utf8),
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        SecItemAdd(query as CFDictionary, nil)
        return created
    }

    private static func read() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
}
