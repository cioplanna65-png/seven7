import Foundation
import CryptoKit
import Security
import UIKit

struct LicenseFile: Codable, Identifiable, Equatable {
    let id: Int
    let displayName: String
    let version: String
    let sha256: String
    let fileSize: Int
}

struct LicenseValidationResponse: Codable {
    let ok: Bool
    let licenseId: Int?
    let internalId: String?
    let activatedAt: Date?
    let expiresAt: Date?
    let resetRemaining: Bool?
    let files: [LicenseFile]?
    let code: String?
    let message: String?
}

private struct DownloadGrantResponse: Codable {
    let ok: Bool
    let fileId: Int?
    let downloadToken: String?
    let expiresAt: Date?
    let code: String?
    let message: String?
}

enum LicenseError: LocalizedError {
    case invalidResponse
    case rejected(String)
    case downloadRejected
    case checksumMismatch
    case sizeMismatch
    case invalidConfiguration

    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "Resposta inválida do servidor."
        case .rejected(let message): return message
        case .downloadRejected: return "O servidor não autorizou o download."
        case .checksumMismatch: return "A verificação de segurança do patch falhou."
        case .sizeMismatch: return "O tamanho do patch não confere."
        case .invalidConfiguration: return "Configuração da API incompleta."
        }
    }
}

@MainActor
final class LicenseManager: ObservableObject {
    static let baseURL = URL(string: "https://licenkeydash-anvun4wk.manus.space/api/v1")!
    private static let clientID = "ios_XIKJIoCehkT1rg"
    private static let clientSecret = "yLwV_UsMuKKFiTqfzFewQMh8ThZoV5AZoOp26me_3us"

    @Published private(set) var key = ""
    @Published private(set) var files: [LicenseFile] = []
    @Published private(set) var expiresAt: Date?
    @Published private(set) var isAuthenticated = false
    @Published private(set) var isBusy = false
    @Published var errorMessage: String?

    private var monitorTask: Task<Void, Never>?
    private let fingerprint = DeviceFingerprint.value

    deinit { monitorTask?.cancel() }

    func validate(key: String) async -> Bool {
        let normalized = key.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty else {
            errorMessage = "Digite sua key."
            return false
        }
        isBusy = true
        errorMessage = nil
        defer { isBusy = false }
        do {
            let response: LicenseValidationResponse = try await request(
                path: "license/validate",
                method: "POST",
                body: [
                    "key": normalized,
                    "deviceFingerprint": fingerprint,
                    "deviceLabel": UIDevice.current.name,
                    "platform": "ios"
                ]
            )
            guard response.ok else {
                throw LicenseError.rejected(response.message ?? response.code ?? "Key recusada.")
            }
            self.key = normalized
            self.files = response.files ?? []
            self.expiresAt = response.expiresAt
            self.isAuthenticated = true
            return true
        } catch {
            isAuthenticated = false
            files = []
            errorMessage = (error as? LocalizedError)?.errorDescription
                ?? "Falha na resposta da API: \(error.localizedDescription)"
            return false
        }
    }

    func revalidate() async -> Bool {
        guard !key.isEmpty else { return false }
        return await validate(key: key)
    }

    func startMonitoring(onInvalidated: @escaping @MainActor () async -> Void) {
        monitorTask?.cancel()
        monitorTask = Task { [weak self] in
            guard let self else { return }
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 60_000_000_000)
                guard !Task.isCancelled else { return }
                let valid = await self.revalidate()
                if !valid {
                    await onInvalidated()
                    return
                }
            }
        }
    }

    func stopMonitoring() {
        monitorTask?.cancel()
        monitorTask = nil
    }

    func download(_ file: LicenseFile) async throws -> Data {
        guard isAuthenticated, !key.isEmpty else { throw LicenseError.downloadRejected }
        let grant: DownloadGrantResponse = try await request(
            path: "files/\(file.id)/grant",
            method: "POST",
            body: [
                "key": key,
                "deviceFingerprint": fingerprint,
                "deviceLabel": UIDevice.current.name,
                "platform": "ios"
            ]
        )
        guard grant.ok, let token = grant.downloadToken else {
            throw LicenseError.rejected(grant.message ?? grant.code ?? "Download não autorizado.")
        }
        var components = URLComponents(
            url: Self.baseURL.appendingPathComponent("download/\(token)"),
            resolvingAgainstBaseURL: false
        )!
        components.queryItems = [URLQueryItem(name: "deviceFingerprint", value: fingerprint)]
        var request = URLRequest(url: components.url!)
        addHeaders(to: &request)
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw LicenseError.downloadRejected
        }
        guard data.count == file.fileSize else { throw LicenseError.sizeMismatch }
        let digest = SHA256.hash(data: data).map { String(format: "%02x", $0) }.joined()
        guard digest.caseInsensitiveCompare(file.sha256) == .orderedSame else {
            throw LicenseError.checksumMismatch
        }
        return data
    }

    private func request<T: Decodable>(
        path: String,
        method: String,
        body: [String: String]
    ) async throws -> T {
        var request = URLRequest(url: Self.baseURL.appendingPathComponent(path))
        request.httpMethod = method
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        addHeaders(to: &request)
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw LicenseError.invalidResponse
        }
        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .custom { decoder in
            let value = try decoder.singleValueContainer().decode(String.self)
            let formatter = ISO8601DateFormatter()
            formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
            if let date = formatter.date(from: value) { return date }
            formatter.formatOptions = [.withInternetDateTime]
            if let date = formatter.date(from: value) { return date }
            throw DecodingError.dataCorruptedError(
                in: try decoder.singleValueContainer(),
                debugDescription: "Invalid ISO-8601 date: \(value)"
            )
        }
        return try decoder.decode(T.self, from: data)
    }

    private func addHeaders(to request: inout URLRequest) {
        request.setValue(Self.clientID, forHTTPHeaderField: "X-Client-Id")
        request.setValue(Self.clientSecret, forHTTPHeaderField: "X-Client-Secret")
    }
}

enum DeviceFingerprint {
    private static let service = "seven7.license"
    private static let account = "device-fingerprint"

    static var value: String {
        if let existing = read(), !existing.isEmpty { return existing }
        let created = UUID().uuidString
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecValueData as String: Data(created.utf8),
            kSecAttrAccessible as String: kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        ]
        SecItemAdd(query as CFDictionary, nil)
        return created
    }

    private static func read() -> String? {
        let query: [String: Any] = [
            kSecClass as String: kSecClassGenericPassword,
            kSecAttrService as String: service,
            kSecAttrAccount as String: account,
            kSecReturnData as String: true,
            kSecMatchLimit as String: kSecMatchLimitOne
        ]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
              let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
}
