# Gerar o IPA sem Mac

Este fork inclui um workflow que usa um runner macOS do GitHub Actions para compilar o app e montar o arquivo `Seven7-unsigned.ipa` com `Payload/Seven7.app`.

## Procedimento

1. Crie um repositório novo no GitHub ou faça upload deste projeto para um repositório seu.
2. Mantenha o repositório público para usar os runners macOS gratuitos do GitHub Actions.
3. Abra a aba **Actions** do repositório.
4. Selecione **Build Seven 7 IPA**.
5. Clique em **Run workflow**.
6. Aguarde o build terminar.
7. Abra o job concluído e baixe o artefato **Seven7-unsigned-ipa**.
8. Extraia o ZIP baixado apenas se o GitHub tiver baixado o artefato como ZIP; o arquivo dentro dele será `Seven7-unsigned.ipa`.
9. Envie `Seven7-unsigned.ipa` para o ESign e use a opção de assinar/importar.

O workflow não usa certificado nem segredo de assinatura. Ele produz um IPA sem assinatura para o ESign assinar no dispositivo. O bundle identifier original `com.apple.mobile.MobileHouseArrest` foi preservado porque o projeto depende dele para o fluxo MHA-C2.
