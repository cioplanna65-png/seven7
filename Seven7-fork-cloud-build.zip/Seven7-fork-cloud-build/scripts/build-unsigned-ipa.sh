#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
BUILD_DIR="$ROOT_DIR/build"
PAYLOAD_DIR="$BUILD_DIR/Payload"

rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR"

xcodebuild \
  -project "$ROOT_DIR/ThreeOneOSFive.xcodeproj" \
  -target 3105 \
  -configuration Release \
  -sdk iphoneos \
  -destination 'generic/platform=iOS' \
  CODE_SIGNING_ALLOWED=NO \
  CODE_SIGNING_REQUIRED=NO \
  CODE_SIGN_IDENTITY="" \
  DEVELOPMENT_TEAM="" \
  build

APP_PATH="$BUILD_DIR/Release-iphoneos/Seven7.app"
if [[ -z "$APP_PATH" || ! -d "$APP_PATH" ]]; then
  echo "Erro: o build não produziu um .app" >&2
  exit 1
fi

mkdir -p "$PAYLOAD_DIR"
cp -R "$APP_PATH" "$PAYLOAD_DIR/Seven7.app"

# O ESign espera um IPA ZIP com Payload na raiz.
(
  cd "$BUILD_DIR"
  zip -qry "$ROOT_DIR/Seven7-unsigned.ipa" Payload
)

unzip -tq "$ROOT_DIR/Seven7-unsigned.ipa"
echo "IPA gerado: $ROOT_DIR/Seven7-unsigned.ipa"
